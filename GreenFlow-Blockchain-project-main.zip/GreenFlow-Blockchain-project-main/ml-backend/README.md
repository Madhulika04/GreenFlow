# DeepLearning Future Predictor
An LSTM and GRU Combained of Convolutional Neural Network. To predict the future co2 emission by the past data of industry.
