from app import *
import views.views as views


if __name__ == "__main__":
    app.run(host='0.0.0.0', port='3000')